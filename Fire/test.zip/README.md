

With this extension you can make your youtube experience more colorful.

Red
![screenshot](images/redScreen.JPG "screenshot")
Pastel
![screenshot](images/pastelScreen.JPG "screenshot")
Navy
![screenshot](images/NavySC.JPG "screenshot")
Gray
![screenshot](images/graySc.JPG "screenshot")
Mint
![screenshot](images/MintScreen.JPG "screenshot")
rose
![screenshot](images/roseScreen.JPG "screenshot")
feather
![screenshot](images/featherScreen.JPG "screenshot")
fox
![screenshot](images/foxScreen.JPG "screenshot")
sweater
![screenshot](images/sweatherScreen.jpg "screenshot")
Other themes will be added over time.
(Icons in popup/options page are mostly from https://www.design-seeds.com/by-collection/ and I do not own any of the pictures used as backgrounds)
